from PyroUbot import *

__MODULE__ = "𝙵𝙾𝙽𝚃"
__HELP__ = """
perintah : <code>{0}font</code>
    reply text, merubah text menjadi berbeda</blockquote>
"""

